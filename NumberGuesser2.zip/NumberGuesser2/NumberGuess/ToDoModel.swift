//
//  ToDoModel.swift
//  NumberGuess
//
//  Created by Fabian Kopf on 16.12.21.
//

import Foundation

class ToDo{
    var id = 0
    var title = ""
}
class ToDoModel{
    var todos = [ToDo]()
}
